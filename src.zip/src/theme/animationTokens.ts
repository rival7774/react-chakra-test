export const animationTokens = {
  seconds: '0.3s',
}
