import type { icons } from '@/assets/icons/icons'

export type IconName = keyof typeof icons
