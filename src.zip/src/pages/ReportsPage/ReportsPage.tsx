export const ReportsPage = () => {
    return (
        <>
            ReportsPage
        </>
    )
}
