import { Box, Flex, Spinner, Tabs, Text, useBreakpointValue } from '@chakra-ui/react'
import { useEffect, useMemo, useState } from 'react'
import { ButtonDefault } from '@/components/common/ButtonDefault/ButtonDefault'
import { DefaultModal } from '@/components/common/ModalDefault/ModalDefault'
import { RequestForm } from '@/pages/RequestPage/components/RequestPageForm/RequestPageForm'
import { Form } from '@/types/Form'
import { ActionsFormDes } from '@/pages/RequestPage/components/ActionsFormDes/ActionsFormDes'
import { mockRequests } from '@/pages/RequestPage/mock/mockRequests'
import { Request } from './types/types'
import { RequestsMobileList } from '@/pages/RequestPage/components/RequestsMobileList/RequestsMobileList'
import { RequestsTable } from '@/pages/RequestPage/components/RequestsTable/RequestsTable'
import { SearchInput } from '@/components/common/SearchInput/SearchInput'

type TabItem = { value: string; label: string }

export const RequestsPage = () => {
  const isMobile = Boolean(useBreakpointValue({ base: true, md: false }))

  const [requests, setRequests] = useState<Request[]>([])
  const [loading, setLoading] = useState(true)

  const [status, setStatus] = useState<string>('all')
  const [search, setSearch] = useState('')
  const [onlyMine, setOnlyMine] = useState(false)

  const [form, setForm] = useState<Form>({
    pharmacy: '',
    category: '',
    theme: '',
    priority: 'Средний',
    warranty: false,
    description: '',
    files: [],
  })

  const [isOpenPopup, setIsOpenPopup] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => {
      setRequests(mockRequests)
      setLoading(false)
    }, 2000)

    return () => clearTimeout(timer)
  }, [])

  const tabsDesktop: TabItem[] = [
    { value: 'new', label: 'Новые' },
    { value: 'rejected', label: 'Отклонены' },
    { value: 'review', label: 'На рассмотрении' },
    { value: 'inProgress', label: 'В работе' },
    { value: 'waitingParts', label: 'Ожидают запчасти' },
    { value: 'done', label: 'Готовы' },
    { value: 'closed', label: 'Закрыты' },
    { value: 'all', label: 'Все статусы' },
  ]

  const tabsMobile: TabItem[] = [
    { value: 'all', label: 'Все статусы' },
    { value: 'new', label: 'Новые' },
    { value: 'inProgress', label: 'В работе' },
    { value: 'done', label: 'Готовы' },
    { value: 'closed', label: 'Закрыты' },
  ]

  const tabs = isMobile ? tabsMobile : tabsDesktop

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase()

    return requests.filter((r) => {
      const matchStatus = status === 'all' ? true : r.status === status
      const matchMine = onlyMine ? Boolean(r.mine) : true

      const matchSearch =
        q.length === 0
          ? true
          : r.id.toLowerCase().includes(q) ||
            r.theme.toLowerCase().includes(q) ||
            r.pharmacyTitle.toLowerCase().includes(q) ||
            r.pharmacyNo.toLowerCase().includes(q)

      return matchStatus && matchMine && matchSearch
    })
  }, [requests, status, onlyMine, search])

  const clearForm = () => {
    setForm({
      pharmacy: '',
      category: '',
      theme: '',
      priority: 'Средний',
      warranty: false,
      description: '',
      files: [],
    })
  }

  const update = <K extends keyof Form>(key: K, value: Form[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }))
  }

  const closeModal = () => setIsOpenPopup(false)
  const openModal = () => setIsOpenPopup(true)

  const submit = () => {
    if (isMobile && !form.pharmacy) return

    console.log(form)
    closeModal()
    clearForm()
  }

  const canCreateMobile = Boolean(form.pharmacy)

  return (
    <Box>
      {/* Desktop header: поиск + экспорт + создать */}
      {!isMobile && (
        <Flex align='center' gap='10px' mb='12px'>
          <Box flex='1'>
            <SearchInput
              value={search}
              onChange={setSearch}
              placeholder='Поиск по номеру или теме заявки'
            />
          </Box>

          <ButtonDefault
            iconSize={14}
            iconName='pdf'
            color='text.primary'
            colorIcon='text.primary'
            p='7px 14px'
            bg='text.btnLight'
            text='Экспорт'
            onClick={() => console.log('export')}
            _hover={{ opacity: 0.9 }}
          />

          <ButtonDefault
            iconSize={14}
            iconName='plus'
            color='text.btnLight'
            colorIcon='text.btnLight'
            p='7px 14px'
            bg='text.primary'
            text='Создать новую заявку'
            onClick={openModal}
          />
        </Flex>
      )}

      <Box pb={isMobile ? '110px' : '0'}>
        {/* Tabs + "Показать только мои" ВНУТРИ Tabs.List (как в макете) */}
        <Tabs.Root value={status} onValueChange={(e) => setStatus(e.value)}>
          <Tabs.List gap='8px' whiteSpace='nowrap' overflowX='auto' overflowY='hidden' pb='2px'>
            {tabs.map((t) => (
              <Tabs.Trigger
                key={t.value}
                value={t.value}
                borderRadius='8px'
                px='12px'
                py='8px'
                bg='gray.100'
                _hover={{ bg: 'gray.200' }}
                _selected={{ bg: 'text.primary', color: 'text.btnLight' }}
                flexShrink={0}
              >
                {t.label}
              </Tabs.Trigger>
            ))}

            {/* Разделитель + кнопка "Показать только мои" (десктоп), скроллится вместе с табами */}
            {!isMobile && (
              <>
                <Box w='1px' h='28px' bg='gray.200' alignSelf='center' flexShrink={0} mx='4px' />

                <Box flexShrink={0}>
                  <ButtonDefault
                    text='Показать только мои'
                    iconName='filter'
                    iconSize={16}
                    p='8px 14px'
                    bg={onlyMine ? 'text.primary' : 'text.btnLight'}
                    color={onlyMine ? 'text.btnLight' : 'text.primary'}
                    colorIcon={onlyMine ? 'text.btnLight' : 'text.primary'}
                    borderRadius='8px'
                    onClick={() => setOnlyMine((prev) => !prev)}
                  />
                </Box>
              </>
            )}
          </Tabs.List>
        </Tabs.Root>

        <Box mt='16px'>
          {loading ? (
            <Flex justify='center' align='center' h='300px'>
              <Spinner size='lg' />
            </Flex>
          ) : filtered.length === 0 ? (
            <Flex justify='center' align='center' h='220px'>
              <Text color='gray.500'>Ничего не найдено</Text>
            </Flex>
          ) : isMobile ? (
            <RequestsMobileList data={filtered} />
          ) : (
            <RequestsTable data={filtered} />
          )}
        </Box>
      </Box>

      <DefaultModal
        isOpen={isOpenPopup}
        onClose={closeModal}
        isMobile={isMobile}
        title={'Создание заявки'}
        footer={
          <>
            {!isMobile ? (
              <ActionsFormDes closeModal={closeModal} submit={submit} />
            ) : (
              <>
                <ButtonDefault
                  text='Прикрепить файлы'
                  iconName='plus'
                  bg='text.btnLight'
                  p='13px'
                  borderRadius='5px'
                  color='text.primary'
                />
                <ButtonDefault
                  text='Создать заявку'
                  disabled={!canCreateMobile}
                  p='13px'
                  borderRadius='5px'
                  bg='text.primary'
                  type='submit'
                  form='requestForm'
                  onClick={submit}
                />
              </>
            )}
          </>
        }
      >
        <RequestForm form={form} update={update} isMobile={isMobile} errors={{}} />
      </DefaultModal>

      {/* Mobile bottom bar */}
      {isMobile && (
        <Box
          position='fixed'
          left='0'
          right='0'
          bottom='0'
          bg='surface.white'
          borderTop='1px solid'
          borderColor='border.default'
          px='16px'
          py='12px'
          zIndex={20}
        >
          <Flex direction='column' gap='10px'>
            <SearchInput
              value={search}
              onChange={setSearch}
              placeholder='Поиск по номеру или теме заявки'
            />

            <ButtonDefault
              iconSize={14}
              iconName='plus'
              color='text.btnLight'
              colorIcon='text.btnLight'
              p='13px'
              bg='text.primary'
              text='Создать новую заявку'
              onClick={openModal}
            />
          </Flex>
        </Box>
      )}
    </Box>
  )
}
