import { Box, Text } from '@chakra-ui/react'
import { Request } from '../../types/types'

const getGroupLabel = (dateStr: string) => {
  const date = new Date(dateStr)
  const today = new Date()
  const yesterday = new Date()
  yesterday.setDate(today.getDate() - 1)

  if (date.toDateString() === today.toDateString()) return 'СЕГОДНЯ'
  if (date.toDateString() === yesterday.toDateString()) return 'ВЧЕРА'

  return `В ${date
    .toLocaleString('ru-RU', {
      month: 'long',
      year: 'numeric',
    })
    .toUpperCase()}`
}

const orderWeight = (label: string) => {
  if (label === 'СЕГОДНЯ') return 0
  if (label === 'ВЧЕРА') return 1
  return 2
}

export const RequestsMobileList = ({ data }: { data: Request[] }) => {
  const grouped = data.reduce(
    (acc, r) => {
      const label = getGroupLabel(r.createdAt)
      if (!acc[label]) acc[label] = []
      acc[label].push(r)
      return acc
    },
    {} as Record<string, Request[]>
  )

  const groupsSorted = Object.entries(grouped).sort(([a], [b]) => {
    const wa = orderWeight(a)
    const wb = orderWeight(b)
    if (wa !== wb) return wa - wb
    return a.localeCompare(b, 'ru')
  })

  return (
    <Box>
      {groupsSorted.map(([group, items]) => (
        <Box key={group} mb={6}>
          <Text fontWeight='bold' mb={3}>
            {group}
          </Text>

          {items.map((r) => (
            <Box key={r.id} p={4} borderRadius='12px' bg='gray.50' mb={3}>
              <Text fontWeight='600'>{r.theme}</Text>
              <Text fontSize='sm' color='gray.600'>
                {r.id} • {r.pharmacyNo} {r.pharmacyTitle}
              </Text>
            </Box>
          ))}
        </Box>
      ))}
    </Box>
  )
}
