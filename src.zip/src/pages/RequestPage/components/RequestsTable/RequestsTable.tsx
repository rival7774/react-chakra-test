import { Badge, Box, Flex, HStack, Table, Text } from '@chakra-ui/react'
import { MyIcon } from '@/components/common/MyIcon/MyIcon'
import { Request } from '../../types/types'

const statusLabel: Record<Request['status'], string> = {
  new: 'Новая',
  inProgress: 'В работе',
  done: 'Готово',
  closed: 'Закрыто',
  paused: 'На паузе',
  rejected: 'Отклонена',
  review: 'На рассмотрении',
  waitingParts: 'Ожидают запчасти',
}

const statusBadgeProps = (s: Request['status']) => {
  switch (s) {
    case 'new':
      return { bg: '#F2E9FF', color: '#7B3FF2' }
    case 'inProgress':
      return { bg: '#FFE9B5', color: '#8A5A00' }
    case 'done':
      return { bg: '#D9F8E2', color: '#0A7A2A' }
    case 'closed':
      return { bg: '#EAEAEA', color: '#333333' }
    case 'paused':
      return { bg: '#FFE1C4', color: '#8A3B00' }
    default:
      return { bg: '#EAEAEA', color: '#333333' }
  }
}

const priorityView = (
  p: Request['priority']
): {
  icon: 'twoArrowsUp' | 'bigTriangle' | 'square' | 'arrowPriorityDown'
  colorToken: 'icon.up' | 'icon.square' | 'icon.down'
} => {
  switch (p) {
    case 'Критич.':
      return { icon: 'twoArrowsUp', colorToken: 'icon.up' }
    case 'Высокий':
      return { icon: 'bigTriangle', colorToken: 'icon.up' }
    case 'Средний':
      return { icon: 'square', colorToken: 'icon.square' }
    case 'Низкий':
      return { icon: 'arrowPriorityDown', colorToken: 'icon.down' }
  }
}

const HeaderCell = ({ title }: { title: string }) => (
  <Flex align='center' gap='8px'>
    <Text fontSize='12px' fontWeight='500' color='text.primary'>
      {title}
    </Text>
    <Box ms='auto' opacity={0.6}>
      <MyIcon name='filter' size={14} />
    </Box>
  </Flex>
)

export const RequestsTable = ({ data }: { data: Request[] }) => {
  return (
    <Box overflowX='auto' overflowY='hidden'>
      <Table.Root size='sm' minW='1200px'>
        <Table.Header>
          <Table.Row bg='gray.50' borderBottom='1px solid' borderColor='border.default'>
            <Table.ColumnHeader w='110px'>
              <HeaderCell title='№' />
            </Table.ColumnHeader>
            <Table.ColumnHeader w='260px'>
              <HeaderCell title='Аптека' />
            </Table.ColumnHeader>
            <Table.ColumnHeader w='160px'>
              <HeaderCell title='Создана' />
            </Table.ColumnHeader>
            <Table.ColumnHeader w='140px'>
              <HeaderCell title='Приоритет' />
            </Table.ColumnHeader>
            <Table.ColumnHeader w='260px'>
              <HeaderCell title='Тема' />
            </Table.ColumnHeader>
            <Table.ColumnHeader w='160px'>
              <HeaderCell title='Категория' />
            </Table.ColumnHeader>
            <Table.ColumnHeader w='160px'>
              <HeaderCell title='Техник' />
            </Table.ColumnHeader>
            <Table.ColumnHeader w='120px'>
              <HeaderCell title='Реакция' />
            </Table.ColumnHeader>
            <Table.ColumnHeader w='140px'>
              <HeaderCell title='Решение' />
            </Table.ColumnHeader>
            <Table.ColumnHeader w='140px'>
              <HeaderCell title='Статус' />
            </Table.ColumnHeader>
          </Table.Row>
        </Table.Header>

        <Table.Body>
          {data.map((r) => {
            const d = new Date(r.createdAt)
            const date = d.toLocaleDateString('ru-RU')
            const time = d.toLocaleTimeString('ru-RU', {
              hour: '2-digit',
              minute: '2-digit',
              second: '2-digit',
            })

            const pr = priorityView(r.priority)

            // --- Реакция (иконка есть только если есть значение) ---
            const showReactionIcon = Boolean(r.reaction)
            const reactionColor = r.reaction ? 'text.primary' : 'text.placeholderSearch'

            // --- Решение (иконка есть всегда если есть значение; нет значения => прочерк, без иконки) ---
            const showResolutionIcon = Boolean(r.resolution)

            const resolutionColor =
              r.resolutionState === 'error'
                ? 'icon.up' // красный
                : r.resolutionState === 'ok'
                  ? 'icon.ok' // зелёный
                  : 'text.primary' // none -> "черное среднее" (если хочешь серое — поменяй на text.placeholderSearch)

            const resolutionIcon =
              r.resolutionState === 'error'
                ? 'error'
                : r.resolutionState === 'ok'
                  ? 'statusOk'
                  : 'time' // none -> нейтральная иконка, но всё равно есть

            return (
              <Table.Row
                key={r.id}
                h='44px'
                borderBottom='1px solid'
                borderColor='border.default'
                _hover={{ bg: 'gray.50' }}
              >
                <Table.Cell fontSize='13px' color='text.primary'>
                  {r.id}
                </Table.Cell>

                <Table.Cell>
                  <HStack gap='10px'>
                    <Badge
                      bg='gray.200'
                      color='text.primary'
                      borderRadius='6px'
                      px='8px'
                      py='2px'
                      fontSize='12px'
                    >
                      {r.pharmacyNo}
                    </Badge>
                    <Text fontSize='13px' color='text.primary' lineClamp={1}>
                      {r.pharmacyTitle}
                    </Text>
                  </HStack>
                </Table.Cell>

                <Table.Cell>
                  <Text fontSize='13px' color='text.primary'>
                    {date}
                  </Text>
                  <Text fontSize='12px' color='text.placeholderSearch'>
                    {time}
                  </Text>
                </Table.Cell>

                <Table.Cell>
                  <HStack gap='8px'>
                    <Box color={pr.colorToken}>
                      <MyIcon name={pr.icon} size={14} />
                    </Box>
                    <Text fontSize='13px' color='text.primary'>
                      {r.priority}
                    </Text>
                  </HStack>
                </Table.Cell>

                <Table.Cell>
                  <Text fontSize='13px' color='text.primary' lineClamp={1}>
                    {r.theme}
                  </Text>
                </Table.Cell>

                <Table.Cell>
                  <Text fontSize='13px' color='text.primary' lineClamp={1}>
                    {r.category}
                  </Text>
                </Table.Cell>

                <Table.Cell>
                  <Text fontSize='13px' color='text.primary' lineClamp={1}>
                    {r.technician || '—'}
                  </Text>
                </Table.Cell>

                {/* Реакция */}
                <Table.Cell>
                  <HStack gap='6px'>
                    {showReactionIcon ? (
                      <Box color='text.primary'>
                        <MyIcon name='time' size={14} />
                      </Box>
                    ) : null}

                    <Text fontSize='13px' color={reactionColor}>
                      {r.reaction || '—'}
                    </Text>
                  </HStack>
                </Table.Cell>

                {/* Решение */}
                <Table.Cell>
                  <HStack gap='6px'>
                    {showResolutionIcon ? (
                      <Box color={resolutionColor}>
                        <MyIcon name={resolutionIcon} size={14} />
                      </Box>
                    ) : null}

                    <Text
                      fontSize='13px'
                      color={r.resolution ? resolutionColor : 'text.placeholderSearch'}
                    >
                      {r.resolution || '—'}
                    </Text>
                  </HStack>
                </Table.Cell>

                <Table.Cell>
                  <Badge
                    borderRadius='8px'
                    px='10px'
                    py='4px'
                    fontSize='12px'
                    {...statusBadgeProps(r.status)}
                  >
                    {statusLabel[r.status]}
                  </Badge>
                </Table.Cell>
              </Table.Row>
            )
          })}
        </Table.Body>
      </Table.Root>
    </Box>
  )
}
