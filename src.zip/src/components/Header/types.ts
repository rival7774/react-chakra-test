export type Page = {
    path: string;
    label: string;
};
