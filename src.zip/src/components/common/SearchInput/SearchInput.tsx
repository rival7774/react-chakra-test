import React, { useEffect, useState } from 'react'
import { Box, Input, InputGroup } from '@chakra-ui/react'
import { MyIcon } from '@/components/common/MyIcon/MyIcon' // поправь путь при необходимости

type Props = {
  value: string
  onChange: (v: string) => void
  placeholder?: string
  debounceTime?: number
  inputStyles?: React.CSSProperties
}

export const SearchInput: React.FC<Props> = ({
  value,
  onChange,
  placeholder = 'Поиск...',
  debounceTime = 200,
  inputStyles,
}) => {
  const [innerValue, setInnerValue] = useState(value)

  useEffect(() => {
    setInnerValue(value)
  }, [value])

  useEffect(() => {
    const handler = setTimeout(() => {
      onChange(innerValue)
    }, debounceTime)

    return () => clearTimeout(handler)
  }, [innerValue, debounceTime, onChange])

  const handleClear = () => {
    setInnerValue('')
    onChange('')
  }

  return (
    <InputGroup
      startElement={<MyIcon name='search' size={17} color='icon.search' />}
      endElement={
        innerValue ? (
          <Box
            cursor='pointer'
            onClick={handleClear}
            display='flex'
            alignItems='center'
            justifyContent='center'
            h='100%'
          >
            <MyIcon name='cross' size={14} color='text.primary' />
          </Box>
        ) : null
      }
    >
      <Input
        value={innerValue}
        onChange={(e) => setInnerValue(e.target.value)}
        placeholder={placeholder}
        _placeholder={{ color: 'text.placeholderSearch' }}
        p='8px 10px 10px 47px'
        color='text.placeholderSearch'
        borderColor='border.default'
        bg='surface.white'
        _focusVisible={{
          borderColor: 'text.primary',
          boxShadow: '0 0 0 1px #3182CE',
        }}
        style={inputStyles}
      />
    </InputGroup>
  )
}
