export type BaseOption = {
  value: string
  label: string
}
