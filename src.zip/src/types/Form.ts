export type Form = {
  pharmacy: string
  category: string
  theme: string
  priority: string
  warranty: boolean
  description: string
  files: File[]
}
